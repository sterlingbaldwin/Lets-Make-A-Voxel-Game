﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WaterVisual : MonoBehaviour {

    public GameObject landGO;
    public GameObject waterGO;

    



	// Use this for initialization
	void Start () {

        for (int x = 0; x < 11; x++) {
            for (int z = 0; z < 11; z++) {

                GameObject landClone = Instantiate(landGO);
                landClone.transform.position = new Vector3(x, 0f, z);
                landClone.transform.parent = transform;
            }
        }

        GameObject waterClone = Instantiate(waterGO);
        waterClone.transform.position = new Vector3(5f, 1f, 5f);







	}
	
	// Update is called once per frame
	void Update () {
		
	}
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Test_GrayToBump : MonoBehaviour {

    public float xDelta;
    public float yDelta;
    public float distortion;

    public Texture2D gray;
    public Texture2D bump;

	// Use this for initialization
	void Start () {
        
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    public void DistortPixels (Texture2D tex) {
        
    }

    public float Curve (float x, float distortion) {

        return 1f / (1f + Mathf.Exp(-Mathf.Lerp(5f, 15f, distortion) * (x - 0.5f)));
    }

    public Texture2D ToNormalMap (Texture2D tex) {

        Texture2D norm = new Texture2D(tex.width, tex.height, TextureFormat.ARGB32, false);

        for (int x = 0; x < tex.width; x++) {
            for (int y = 0; y < tex.height; y++) {

                Color oldColor = tex.GetPixel(x, y);
                Color newColor = new Color() { r = oldColor.g, g = oldColor.g, b = oldColor.g, a = oldColor.r };
                norm.SetPixel(x, y, newColor);

            }
        }

        norm.Apply();
        return norm;
    }
}

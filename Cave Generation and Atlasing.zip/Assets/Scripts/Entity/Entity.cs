﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Entity : MonoBehaviour {
    
    public Stack<Vector3Int> path;
    public float moveSpeed = 7f;

    Vector3 goalPosition;
    
    // Update is called once per frame
    void Update() {

        if (path == null) return;

        if (path.Count == 0) {
            goalPosition = transform.position;
        }

        if (path.Count > 0 && Mathf.Abs(transform.position.x - goalPosition.x) < Mathf.Epsilon && Mathf.Abs(transform.position.y - goalPosition.y) < Mathf.Epsilon) {

            goalPosition = path.Pop();

        } else {

            transform.position = Vector3.MoveTowards(transform.position, goalPosition, Time.deltaTime * moveSpeed);
        }
    }

    

    public void FindPath (Vector3Int destination) {

        moveSpeed = 7f;
        goalPosition = transform.position;

        Vector3Int start = new Vector3Int() {
            x = Mathf.FloorToInt(transform.position.x),
            y = Mathf.FloorToInt(transform.position.y),
            z = Mathf.FloorToInt(transform.position.z)
        };

        AStar.FindPath(start, destination, out path);
    }
}

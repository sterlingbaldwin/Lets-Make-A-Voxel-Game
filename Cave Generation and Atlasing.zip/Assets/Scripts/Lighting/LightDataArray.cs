﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LightDataArray {

    public byte[] red, green, blue, sun;

    public LightDataArray (int ChunkSize) {

        red = new byte[ChunkSize * ChunkSize * ChunkSize];
        green = new byte[ChunkSize * ChunkSize * ChunkSize];
        blue = new byte[ChunkSize * ChunkSize * ChunkSize];
        sun = new byte[ChunkSize * ChunkSize * ChunkSize];

    }
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public partial class ThreadManager {

    public class BlockBuilder : ThreadedProcess {

        

        Chunk chunk;
        Block[] blocks;
        List<int> lightSourceIndices;
        bool isAir;

        public BlockBuilder (Chunk chunk) {

            this.chunk = chunk;
        }

        protected override void ThreadFunction() {
            //NOTE: For now, block id 0 = Air, id 1 = Filled, id 2 = LightSource

            isAir = true;
            lightSourceIndices = new List<int>();
            blocks = new Block[Chunk.size * Chunk.size * Chunk.size];

            float caveTuning = (Mathf.Sin((chunk.position.x / 256f)) + 3.5f);
            
            int idx = 0;
            for (int x = 0; x < Chunk.size; x++) {
                for (int y = 0; y < Chunk.size; y++) {
                    for (int z = 0; z < Chunk.size; z++) {

                        int _X = x + chunk.position.x + GameManager._seed;
                        int _Z = z + chunk.position.z + GameManager._seed;

                        float height = Mathf.PerlinNoise((_X) / 64f + 756, (_Z) / 64f) * 16f
                            + Mathf.PerlinNoise((_X) / 16f - 5778, (_Z) / 16f +78) * 4f
                            + Mathf.PerlinNoise((_X) / 256f, (_Z) / 256f + 567) * 96f
                            + Mathf.PerlinNoise((_X) / 128f - 7798, (_Z) / 64f +120) * 48f
                            + Mathf.PerlinNoise((_X) / 64f, (_Z) / 96f + 4800) * 32f
                            + Mathf.PerlinNoise((_X) / 256f + 846, (_Z) / 128f + 12) * 72f
                            + 160f;

                        if (y + chunk.position.y < height) {

                            if (GetNoise3D(_X, y + chunk.position.y, _Z) < caveTuning) {


                                blocks[idx].value = 0x20;
                                isAir = false;
                            }

                        }
                        

                        idx++;
                    }
                }
            }
        }

        float GetNoise3D (int x, int y, int z) {

            return Mathf.PerlinNoise(x / 32f, y / 32f) + 
                Mathf.PerlinNoise(x / 32f, z / 32f) + 
                Mathf.PerlinNoise(y / 32f, z / 32f) + 
                Mathf.PerlinNoise(y / 32f, x / 32f) + 
                Mathf.PerlinNoise(z / 32f, x / 32f) + 
                Mathf.PerlinNoise(z / 32f, y  / 32f);

        }

        protected override void OnFinished() {

            chunk.OnBlockDataFinished(blocks, lightSourceIndices, isAir);
        }
    }
}


﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class BlockExtensions {

    //Blocks are a container class for an int
    //Each bit is partitioned for data that is shared between all blocks

    //Partition:
    //  Utility     - 1 bit
    //  Shape Type  - 4 bits
    //  Shader Type - 2 bits
    //  Block Type  - 16 bits
    //  Unused      - 1 bit
    //  Metadata    - 4 bits
    //  Rotation    - 4 bits
    //  NOTE: Utility blocks use the remaining 31 bits for pathfinding data

    //Summary: Check if block is utility (used for pathfinding, denotes air, and others)
    public static bool IsUtility (this Block block) {

        return (block.value & 0x80000000) != 0;
    }

    //Summary: Get the shape type if block is NOT utility
    public static int GetShapeType (this Block block) {

        return (block.value & 0x80000000) == 0? (block.value & 0x78000000) >> 27 : -1;
    }

    //Summary: Get the shader type if block is NOT utility
    public static int GetShaderType (this Block block) {

        return (block.value & 0x6000000) >> 25;
    }

    //Summary: Get the block ID if block is NOT utility
    public static int GetBlockID (this Block block) {

        return (block.value & 0xFFFF00) >> 8;
    }

    //Summary: Get the block metadata if block is NOT utility
    public static int GetMetadataType (this Block block) {

        return (block.value & 0xF0) >> 4;
    }

    //Summary: Get the block rotation if block is NOT utility
    public static int GetRotationType (this Block block) {

        return (block.value & 0xF);
    }






    public static bool IsOpaque (this Block block) {

        return block.value != 0x00;
    }

    public static bool CanSeeSide (this Block block, Block neighbor, Vector3Int direction) {

        if (block.value == 0x00) return false;
        if (neighbor.value == 0x00) return true;

        //Proceeds to volmit
        BlockData blockData = BlockManager.GetBlockData(block.value & ~0xF);
        BlockData neighborData = BlockManager.GetBlockData(block.value & ~0xF);

        if (blockData.shapeID == 0 && neighborData.shapeID == 0) return false;

        return true;
    }
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public struct Block {

    //Block Data Partitioning
    //Blocks have 32 bits, but each group of bits will have its own unique functions

    //Shape: 4 bits
    //Block ID: 16 bits
    //Block Metadata: 4 bits
    //Block Rotation: 4 bits



    //Types






    public static readonly int MetadataMask = 0xF0;
    public static readonly int RotationMask = 0x0F;
    public static readonly int BlockIDMask = ~(0xFF);

    public int value;

    public static Block Air = new Block() { value = 0x00 };
    public static Block Utility_Skip = new Block() { value = 0x01 };

}

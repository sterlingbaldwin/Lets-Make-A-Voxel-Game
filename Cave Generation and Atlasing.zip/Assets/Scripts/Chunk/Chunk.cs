﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Chunk {

    private enum ChunkFlags {
        Awake = 0x01,
        StartedBlocks = 0x02,
        HasBlocks = 0x04,
        StartedLights = 0x08,
        HasLights = 0x10,
        StartedMesh = 0x20,
        HasMesh = 0x40
    };

    public static WorldManager world;
    public static int size = 16;

    public Block[] blocks;
    public byte[] red, green, blue, sun;
    public Vector3Int position;

    private ChunkFlags flags;
    private Mesh mesh;

    public Chunk (int x, int y, int z) {

        position.x = x;
        position.y = y;
        position.z = z;

        flags |= ChunkFlags.Awake;
    }

    public bool Tick () {

        if ((flags & ChunkFlags.Awake) == 0x00) return false;

        if ((flags & ChunkFlags.StartedBlocks) == 0x00) {

            ThreadManager.CreateBlockBuilderThread(this);
            flags |= ChunkFlags.StartedBlocks;
        }

        if ((flags & ChunkFlags.HasBlocks) != 0x00 && (flags & ChunkFlags.StartedLights) == 0x00) {

            ThreadManager.CreateLightBuilderThread(this);
            flags |= ChunkFlags.StartedLights;
        }

        if ((flags & ChunkFlags.HasLights) != 0x00 && (flags & ChunkFlags.StartedMesh) == 0x00) {

            ThreadManager.CreateMeshBuilderThread(this);
            flags |= ChunkFlags.StartedMesh;
        }

        return true;
    }

    public void Draw () {

        if ((flags & ChunkFlags.HasMesh) != 0x00) {
            Graphics.DrawMesh(mesh, Matrix4x4.identity, Manager.gameManager.material, 0);
        }
    }

    public void OnBlockDataFinished (Block[] blocks, List<int> lightSourceIndices, bool isAir = false) {

        this.blocks = blocks;

        if (isAir == true) { flags &= ~ChunkFlags.Awake; }
        flags |= ChunkFlags.HasBlocks;

        int max_height = WorldManager.chunksTall * size;

        if (position.y + size >= max_height) {

            for (int x = 0; x < size; x++) {
                for (int z = 0; z < size; z++) {

                    Manager.gameManager.lightMgr.AddSunlightNode(position, (ushort)(x * size * size + (size - 1) * size + z), 31);
                }
            }
        }



    }

    public void OnLightDataFinished (byte[] red, byte[] green, byte[] blue, byte[] sun) {

        this.red = red;
        this.green = green;
        this.blue = blue;
        this.sun = sun;

        flags |= ChunkFlags.HasLights;
    }

    public void OnMeshDataFinished (Mesh graphics, Mesh physics) {

        if (graphics.vertexCount == 0)
            flags &= ~ChunkFlags.Awake;

        mesh = graphics;
        flags |= ChunkFlags.HasMesh;

        if (physics == null) return;
        world.CreateChunkGameObject(this, graphics, physics);


    }

    public Block GetBlockAt (int x, int y, int z) {

        x -= position.x;
        y -= position.y;
        z -= position.z;

        if ((flags & ChunkFlags.HasBlocks) == 0) return Block.Air;
        if (IsPointWithinBounds(x, y, z)) return blocks[PointToIndex(x, y, z)];
        return world.GetBlockAt(x + position.x, y + position.y, z + position.z);
    }

    public void SetBlockAt (int x, int y, int z, int blockID) {

        if ((flags & ChunkFlags.HasBlocks) == 0) return;

        x -= position.x;
        y -= position.y;
        z -= position.z;

        if (IsPointWithinBounds(x, y, z)) {

            blocks[PointToIndex(x, y, z)].value = blockID;
            flags &= ~ChunkFlags.StartedMesh;
        }
    }

    public static Vector2Int WorldCoordinatesToChunkCoordinates (int x, int z) {

        return new Vector2Int(
            Mathf.FloorToInt(x / (float)size) * size,
            Mathf.FloorToInt(z / (float)size) * size
        );
    }

    public static int PointToIndex (int x, int y, int z) {

        return x * size * size + y * size + z;
    }

    public static bool IsPointWithinBounds (int x, int y, int z) {

        return x >= 0 && y >= 0 && z >= 0 && x < size && y < size && z < size;
    }
}

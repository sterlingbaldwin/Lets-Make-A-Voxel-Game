﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class LookAtLibrary {

    public static Vector3Int[][] lookAtVectors;

    static LookAtLibrary () {

        lookAtVectors = new Vector3Int[16][];

        for (int i = 0; i < 16; i++) {

            lookAtVectors[i] = new Vector3Int[6];

            Vector3[] dirs = new Vector3[6] {
                QuaternionLibrary.blockRotations[i] * Vector3.forward,
                QuaternionLibrary.blockRotations[i] * Vector3.right,
                QuaternionLibrary.blockRotations[i] * Vector3.back,
                QuaternionLibrary.blockRotations[i] * Vector3.left,
                QuaternionLibrary.blockRotations[i] * Vector3.up,
                QuaternionLibrary.blockRotations[i] * Vector3.down,
            };

            for (int j = 0; j < 6; j++) {

                lookAtVectors[i][j] = new Vector3Int {
                    x = Mathf.RoundToInt(dirs[j].x),
                    y = Mathf.RoundToInt(dirs[j].y),
                    z = Mathf.RoundToInt(dirs[j].z)
                };
            }
        }
    }

    public static Vector3Int[] GetLookAtVectors (this Block block) {

        return lookAtVectors[block.value & 0xF];
    }
}

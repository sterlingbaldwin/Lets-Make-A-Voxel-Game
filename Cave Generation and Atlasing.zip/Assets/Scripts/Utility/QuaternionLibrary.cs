﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class QuaternionLibrary {

    public static Quaternion[] blockRotations;
    public static Quaternion[] squareFaceRotations;

    static QuaternionLibrary () {

        blockRotations = new Quaternion[4 * 4];

        for (int x = 0; x < 4; x++) {
            for (int y = 0; y < 4; y++) {

                blockRotations[x * 4 + y] = Quaternion.Euler(x * 90, y * 90, 0);
            }
        }

        squareFaceRotations = new Quaternion[6];

        squareFaceRotations[0] = Quaternion.Euler(0f, 0f, -90f);
        squareFaceRotations[1] = Quaternion.Euler(-90f, 0f, 0f);
        squareFaceRotations[2] = Quaternion.Euler(0f, 0f, 90f);
        squareFaceRotations[3] = Quaternion.Euler(90f, 0f, 0f);
        squareFaceRotations[4] = Quaternion.Euler(0f, -90f, 0f);
        squareFaceRotations[5] = Quaternion.Euler(0f, 90f, 0f);

    }

    public static Quaternion GetQuaternionFromDirection (Direction dir) {

        if (dir == Direction.North) return squareFaceRotations[0];
        if (dir == Direction.East) return squareFaceRotations[1];
        if (dir == Direction.South) return squareFaceRotations[2];
        if (dir == Direction.West) return squareFaceRotations[3];
        if (dir == Direction.Up) return squareFaceRotations[4];
        return squareFaceRotations[5];

    }

    public static Quaternion GetRotationFromMetadata (this Block block) {

        return blockRotations[block.value & 0xF];
    }


}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shape {

    public class Face {
        public Vector3[] vertices;
        public Vector2[] uvs;
        public int[] triangles;
        public Vector3 normal;
        public Vector4 tangent;
    }

    public Face[] faces;

    public Shape () {

        faces = new Face[6];
    }

    public void AddFaceData (Direction direction, Vector3[] vertices, Vector2[] uvs, int[] triangles, Vector3 normal, Vector4 tangent) {

        faces[DirectionToIndex(direction)] = new Face() {
            vertices = vertices,
            uvs = uvs,
            triangles = triangles,
            normal = normal,
            tangent = tangent
        };
    }


    public void GetFaces (Direction dir, Face[] inFaces) {

        if (inFaces == null) inFaces = new Face[6];

        if ((dir & Direction.North) != 0x00) inFaces[0] = this.faces[0];
        else inFaces[0] = null;
        if ((dir & Direction.East) != 0x00) inFaces[1] = this.faces[1];
        else inFaces[1] = null;
        if ((dir & Direction.South) != 0x00) inFaces[2] = this.faces[2];
        else inFaces[2] = null;
        if ((dir & Direction.West) != 0x00) inFaces[3] = this.faces[3];
        else inFaces[3] = null;
        if ((dir & Direction.Up) != 0x00) inFaces[4] = this.faces[4];
        else inFaces[4] = null;
        if ((dir & Direction.Down) != 0x00) inFaces[5] = this.faces[5];
        else inFaces[5] = null;
    }

    private int DirectionToIndex (Direction dir) {


        if ((dir & Direction.North) != 0x00) return 0;
        if ((dir & Direction.East) != 0x00) return 1;
        if ((dir & Direction.South) != 0x00) return 2;
        if ((dir & Direction.West) != 0x00) return 3;
        if ((dir & Direction.Up) != 0x00) return 4;
        if ((dir & Direction.Down) != 0x00) return 5;

        return 0;
    }
}

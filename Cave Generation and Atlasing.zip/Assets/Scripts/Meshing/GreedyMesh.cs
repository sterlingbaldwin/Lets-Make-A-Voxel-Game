﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GreedyMesh {


    List<Vector3> vertices = new List<Vector3>();
    List<int> elements = new List<int>();
    

    public void CreateGreedyMesh(Chunk chunk) {

        // This greedy algorithm is converted from PHP to C# from this article:
        // http://0fps.wordpress.com/2012/06/30/meshing-in-a-minecraft-game/
        //
        // The original source code can be found here:
        // https://github.com/mikolalysenko/mikolalysenko.github.com/blob/gh-pages/MinecraftMeshes/js/greedy.js

        int size = Chunk.size;

        for (int d = 0; d < 3; d++) {

            int i, j, k, l, w, h, u = (d + 1) % 3, v = (d + 2) % 3;
            int[] x = new int[3];
            int[] q = new int[3];
            bool[] mask = new bool[size * size];

            q[d] = 1;

            for (x[d] = -1; x[d] < size;) {
                // Compute the mask
                int n = 0;
                for (x[v] = 0; x[v] < size; ++x[v]) {
                    for (x[u] = 0; x[u] < size; ++x[u]) {
                        mask[n++] = (0 <= x[d] ? Data(chunk, x[0], x[1], x[2]) : false) !=
                            (x[d] < size - 1 ? Data(chunk, x[0] + q[0], x[1] + q[1], x[2] + q[2]) : false);
                    }
                }

                // Increment x[d]
                ++x[d];

                // Generate mesh for mask using lexicographic ordering
                n = 0;
                for (j = 0; j < size; ++j) {
                    for (i = 0; i < size;) {
                        if (mask[n]) {

                            // Compute width
                            for (w = 1; i + w < size && mask[n + w]; ++w) ;

                            // Compute height (this is slightly awkward
                            bool done = false;
                            for (h = 1; j + h < size; ++h) {
                                for (k = 0; k < w; ++k) {
                                    if (!mask[n + k + h * size]) {
                                        done = true;
                                        break;
                                    }
                                }
                                if (done) break;
                            }

                            // Add quad
                            x[u] = i;
                            x[v] = j;
                            int[] du = new int[3];
                            int[] dv = new int[3];
                            du[u] = w;
                            dv[v] = h;

                            Debug.Log("W: " + w + " H: " + h + " D: " + d + " U: " + u + " V: " + v + " N: " + n + " X: " + (x[d])
                                
                                
                                
                            );

                            AddFace(chunk,
                            new Vector3(x[0], x[1], x[2]),
                            new Vector3(x[0] + du[0], x[1] + du[1], x[2] + du[2]),
                            new Vector3(x[0] + du[0] + dv[0], x[1] + du[1] + dv[1], x[2] + du[2] + dv[2]),
                            new Vector3(x[0] + dv[0], x[1] + dv[1], x[2] + dv[2]), vertices, elements, false
                            );
                            
                            // Zero-out mask
                            for (l = 0; l < h; ++l) {
                                for (k = 0; k < w; ++k) {
                                    mask[n + k + l * size] = false;
                                }
                            }

                            // Increment counters and continue
                            i += w; n += w;
                        } else {
                            ++i;
                            ++n;
                        }
                    }
                }
            }
        }
    }
 
    private static void AddFace(Chunk ch, Vector3 v1, Vector3 v2, Vector3 v3, Vector3 v4, List<Vector3> vertices, List<int> elements, bool flip = true) {
        
        int index = vertices.Count;

        v1.x += ch.position.x - 0.5f;
        v2.x += ch.position.x - 0.5f;
        v3.x += ch.position.x - 0.5f;
        v4.x += ch.position.x - 0.5f;

        v1.y += ch.position.y - 0.5f;
        v2.y += ch.position.y - 0.5f;
        v3.y += ch.position.y - 0.5f;
        v4.y += ch.position.y - 0.5f;

        v1.z += ch.position.z - 0.5f;
        v2.z += ch.position.z - 0.5f;
        v3.z += ch.position.z - 0.5f;
        v4.z += ch.position.z - 0.5f;

        vertices.Add(v1);
        vertices.Add(v2);
        vertices.Add(v3);
        vertices.Add(v4);

        if (flip) {

            elements.Add(index + 2);
            elements.Add(index + 1);
            elements.Add(index);

            elements.Add(index);
            elements.Add(index + 3);
            elements.Add(index + 2);
        }
        else {

            elements.Add(index);
            elements.Add(index + 1);
            elements.Add(index + 2);

            elements.Add(index + 2);
            elements.Add(index + 3);
            elements.Add(index);
        }

    }

    private static bool Data(Chunk chunk, int x, int y, int z) {

        return chunk.blocks[x * Chunk.size * Chunk.size + y * Chunk.size + z].IsOpaque();
    }

    public Mesh GetMesh () {


        Mesh mesh = new Mesh();
        mesh.Clear();
        mesh.vertices = vertices.ToArray();
        mesh.triangles = elements.ToArray();
        mesh.RecalculateBounds();
        mesh.RecalculateNormals();

        return mesh;
    }
}
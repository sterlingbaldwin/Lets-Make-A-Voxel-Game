﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StructureManager : Manager {

    static Dictionary<int, List<StructureNode>> StructureIDMap;



    class StructureNode {

        public StructureNode (Block block, Vector3Int position) {

            this.block = block;
            this.position = position;
        }

        public Block block;
        public Vector3Int position;
    }

	// Use this for initialization
	public override void Start () {

        StructureIDMap = new Dictionary<int, List<StructureNode>>();

        List<string[]> structureDataFiles = FilePathLibrary.GetAllFileDataInDirectory(FilePathLibrary.structureDataPath);
        for (int i = 0; i < structureDataFiles.Count; i++) {
            ParseDataFile(structureDataFiles[i]);
        }
	}

    void ParseDataFile (string[] data) {

        int id = 0;
        Vector3Int size = new Vector3Int(0, 0, 0);
        List<StructureNode> nodes = new List<StructureNode>();

        for (int i = 0; i < data.Length; i++) {

            if (data[i].Contains("ID: ")) {
                id = int.Parse(data[i].Split(' ')[1]);
                continue;
            }
            if (data[i].Contains("Size: ")) {
                string[] sizeAsAString = data[i].Split(' ');

                size.x = int.Parse(sizeAsAString[1]);
                size.y = int.Parse(sizeAsAString[2]);
                size.z = int.Parse(sizeAsAString[3]);
                continue;
            }
            if (data[i] == "") continue;

            string[] nodeAsString = data[i].Split(' ');

            Block blk = new Block();
            Vector3Int pos = new Vector3Int {
                x = int.Parse(nodeAsString[0]),
                y = int.Parse(nodeAsString[1]),
                z = int.Parse(nodeAsString[2])
            };


            string[] blockInfoAsString = nodeAsString[3].Split(':');
            int blockDataValue = (int.Parse(blockInfoAsString[0]) << 8) | (int.Parse(blockInfoAsString[1]) << 4);

            blk.value = blockDataValue;

            StructureNode node = new StructureNode(blk, pos);
            nodes.Add(node);
        }

    }
	

    public void GenerateStructureAt (int id, Vector3Int offset, Chunk chunk) {


        List<StructureNode> nodes = StructureIDMap[id];

        for (int i = 0; i < nodes.Count; i++) {

            StructureNode next = nodes[i];
            chunk.SetBlockAt(offset.x + next.position.x, offset.y + next.position.y, offset.z + next.position.z, next.block.value);
        }
    }
}

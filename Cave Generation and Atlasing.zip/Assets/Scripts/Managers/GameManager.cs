﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour {

    public static int _seed;


    public bool enableThreading;

    public int chunksTall = 10, radius = 2;
    public int maxThreads = 4, updatesPerTick = 128;

    public bool randomSeed;
    public string seed;

    public Material material;


    public BlockManager blockMgr;
    public StructureManager structureMgr;
    public ShapeManager shapeMgr;
    public TextureAndMaterialManager textureAndMaterialMgr;

    public ThreadManager threadMgr;
    public WorldManager worldMgr;
    public EntityManager entityMgr;
    public LightManager lightMgr;

	// Use this for initialization
	void Start () {

        if (randomSeed) {
            _seed = Random.Range(-100000, 100000);
            seed = _seed.ToString();
        } else
            _seed = (seed.GetHashCode() % 200000) - 100000;



        ThreadedProcess.enableThreading = enableThreading;

        ConstructManagers();
        StartManagers();
	}
	
	// Update is called once per frame
	void Update () {

        UpdateManagers(Time.deltaTime);
	}

    void ConstructManagers () {

        AStar.RegisterWorld(worldMgr);

        blockMgr = new BlockManager();
        structureMgr = new StructureManager();
        shapeMgr = new ShapeManager();
        textureAndMaterialMgr = new TextureAndMaterialManager();

        threadMgr = new ThreadManager(maxThreads, updatesPerTick);
        lightMgr = new LightManager();
        worldMgr = new WorldManager(chunksTall, radius);
        entityMgr = new EntityManager();
    }

    void StartManagers () {

        blockMgr.Start();
        structureMgr.Start();
        shapeMgr.Start();
        textureAndMaterialMgr.Start();

        threadMgr.Start();
        lightMgr.Start();
        worldMgr.Start();
        entityMgr.Start();

    }

    void UpdateManagers (float dt) {

        threadMgr.Update(dt);
        lightMgr.Update(dt);
        worldMgr.Update(dt);
        entityMgr.Update(dt);
    }
}

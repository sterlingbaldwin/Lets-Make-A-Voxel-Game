﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WorldManager : Manager {






    Transform world;
    Dictionary<Chunk, GameObject> chunkGameObjectMap;
    
    static float tickUpdateTimer;
    static float initialGenerationTimer;

    public Dictionary<Vector2Int, Chunk[]> chunkColumnMap;
    public Dictionary<Vector3Int, MeshCollider> meshColliderMap;
    public List<Chunk> activeChunks;

    public static int chunksTall;
    public static int radius;

    public WorldManager (int chunksTall = 10, int radius = 1) {

        tickUpdateTimer = 0f;

        chunkColumnMap = new Dictionary<Vector2Int, Chunk[]>();
        chunkGameObjectMap = new Dictionary<Chunk, GameObject>();
        activeChunks = new List<Chunk>();

        WorldManager.chunksTall = chunksTall;
        WorldManager.radius = radius;

        world = new GameObject("World").transform;

        
    }

    // Use this for initialization
    public override void Start () {

        initialGenerationTimer = Time.realtimeSinceStartup;

        //Note: Do not set this in the constructor.
        Chunk.world = this;

        for (int x = -radius; x <= radius; x++) {
            for (int z = -radius; z <= radius; z++) {

                CreateChunkColumnAt(x * Chunk.size, z * Chunk.size);
            }
        }
	}
	
    public void CreateChunkColumnAt (int x, int z) {

        Vector2Int key = Chunk.WorldCoordinatesToChunkCoordinates(x, z);

        if (chunkColumnMap.ContainsKey(key) == false) {

            Chunk[] column = new Chunk[chunksTall];
            for (int i = 0; i < chunksTall; i++) {
                column[i] = new Chunk(key.x, i * Chunk.size, key.y);
                activeChunks.Add(column[i]);
            }

            chunkColumnMap.Add(key, column);
        }

    }


	// Update is called once per frame
	public override void Update (float dt) {

        tickUpdateTimer += dt;
        bool doTick = tickUpdateTimer >= (1 / 20f);

        for (int i = 0; i < activeChunks.Count; i++) {

            //Is it time to tick?
            if (doTick) {
                //Should this chunk continue ticking
                if (activeChunks[i].Tick() == false) {

                    //if not, sleep
                    activeChunks.RemoveAt(i);
                    i--;
                }
            }
        }

        if (doTick) tickUpdateTimer = 0f;
	}

    public void UpdateChunkWorld () {

        Chunk.world = this;
    }

    public Block GetBlockAt (int x, int y, int z) {

        Chunk ch;
        if (GetChunkAt(x, y, z, out ch)) {
            return ch.GetBlockAt(x, y, z);
        }
        return Block.Air;
    }

    public void SetBlockAt (int x, int y, int z, int id) {

        Chunk ch;
        if (GetChunkAt(x, y, z, out ch)) {
            ch.SetBlockAt(x, y, z, id);
        }
    }

    public bool GetChunkAt (int x, int y, int z, out Chunk ch) {

        Vector2Int key = Chunk.WorldCoordinatesToChunkCoordinates(x, z);

        Chunk[] column;
        if (chunkColumnMap.TryGetValue(key, out column)) {

            int idx = Mathf.FloorToInt(y / (float)Chunk.size);
            if (idx >= 0 && idx < chunksTall) {
                ch = column[idx];
                return true;
            }
        }

        ch = null;
        return false;
    }

    public void CreateChunkGameObject (Chunk chunk, Mesh graphics, Mesh physics) {


        //Does this chunk already have a gameObject?
        GameObject chunkGO;
        if (chunkGameObjectMap.TryGetValue(chunk, out chunkGO)) {

            chunkGO.GetComponent<MeshFilter>().sharedMesh = graphics;
            chunkGO.GetComponent<MeshCollider>().sharedMesh = physics;
            return;
        }

        //No. Create a new one
        Vector3Int position = chunk.position;

        chunkGO = new GameObject("CHUNK_" + position.ToString());
        chunkGO.transform.parent = world;
        chunkGO.isStatic = true;

        MeshFilter mf = chunkGO.AddComponent<MeshFilter>();
        MeshRenderer mr = chunkGO.AddComponent<MeshRenderer>();

        mf.mesh = graphics;
        mr.sharedMaterial = TextureAndMaterialManager.materials[0];

        MeshCollider mc = chunkGO.AddComponent<MeshCollider>();
        mc.sharedMesh = physics;

        chunkGameObjectMap.Add(chunk, chunkGO);


        if (chunkGameObjectMap.Count == 1) {
            initialGenerationTimer = Time.realtimeSinceStartup - initialGenerationTimer;
            Debug.Log("World took " + initialGenerationTimer * 1000 + "ms to generate");
        }

        return;
    }

    public Vector3Int GetBlockPositionFromRaycast (Vector3 point, Vector3 normal, bool getAdjacent) {

        if (getAdjacent) {

            Vector3Int hitPoint = new Vector3Int() {
                x = Mathf.FloorToInt(point.x + 0.5f + normal.x * 0.2f),
                y = Mathf.FloorToInt(point.y + 0.5f + normal.y * 0.2f),
                z = Mathf.FloorToInt(point.z + 0.5f + normal.z * 0.2f)
            };

            return hitPoint;

        } else {

            Vector3Int hitPoint = new Vector3Int() {
                x = Mathf.FloorToInt(point.x + 0.5f - normal.x * 0.2f),
                y = Mathf.FloorToInt(point.y + 0.5f - normal.y * 0.2f),
                z = Mathf.FloorToInt(point.z + 0.5f - normal.z * 0.2f)
            };

            return hitPoint;
        }
    }
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlockManager : Manager {

    public static Dictionary<int, BlockData> blockDataMap;


    public BlockManager () {

    }

    public override void Start () {

        LoadBlocks();
    }

    void LoadBlocks () {

        blockDataMap = new Dictionary<int, BlockData>();
        List<string[]> blockFiles = FilePathLibrary.GetAllFileDataInDirectory(FilePathLibrary.blockDataPath);

        for (int i = 0; i < blockFiles.Count; i++) {
            ParseBlockFile(blockFiles[i]);
        }
    }

    void ParseBlockFile (string[] data) {

        int id = 0;
        string name = "";
        int shapeID = 0;
        int renderType = 0;

        string[] textures = null;
    
        byte red = 0, green = 0, blue = 0;

        float hardness = 0;
        float friction = 0;

        for (int i = 0; i < data.Length; i++) {

            if (data[i].Contains("ID: ")) {
                id = int.Parse(data[i].Split(' ')[1]);
            }
            if (data[i].Contains("Name: ")) {
                name = data[i].Split(' ')[1];
            }
            if (data[i].Contains("Shape: ")) {

                string shapeName = data[i].Split(' ')[1];

                if (shapeName == "Cube") shapeID = 0;
            }
            if (data[i].Contains("RenderType: ")) {

                string renderName = data[i].Split(' ')[1];

                if (renderName == "Opaque") renderType = 0;
                if (renderName == "Cutout") renderType = 1;
                if (renderName == "Transparent") renderType = 2;
            }
            if (data[i].Contains("Illuminance: ")) {

                string[] lightnessAsString = data[i].Split(' ');

                red = byte.Parse(lightnessAsString[1]);
                green = byte.Parse(lightnessAsString[2]);
                blue= byte.Parse(lightnessAsString[3]);
            }
            if (data[i].Contains("Textures: ")) {

                string[] texturesAsString = data[i].Split(' ');

                textures = new string[texturesAsString.Length - 1];

                for (int j = 1; j < texturesAsString.Length; j++) {

                    textures[j - 1] = texturesAsString[j];
                }
            }


        }

        BlockData blkData = new BlockData {
            name = name,
            renderType = renderType,
            shapeID = shapeID,
            textures = textures,
            red = red,
            blue = blue,
            green = green,
            hardness = hardness,
            friction = friction
        };

        blockDataMap.Add(id << 4, blkData);
        
    }

    public static BlockData GetBlockData (int id) {

        BlockData data;
        if (blockDataMap.TryGetValue(id, out data)) return data;
        else {
            Debug.Log(id + " does not exist");
            return null;
        }
    }
}

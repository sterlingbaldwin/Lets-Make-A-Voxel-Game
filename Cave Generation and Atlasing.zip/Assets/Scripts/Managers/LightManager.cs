﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LightManager : Manager {

    public class LightNodeRGB {

        public ushort index;
        public byte red, green, blue;
    }
    public class LightNodeSun {

        public ushort index;
        public byte sun;
    };

    Dictionary<Vector3Int, List<LightNodeRGB>> RGBLightNodes;
    Dictionary<Vector3Int, List<LightNodeSun>> SunLightNodes;

	// Use this for initialization
	public override void Start () {

        RGBLightNodes = new Dictionary<Vector3Int, List<LightNodeRGB>>();
        SunLightNodes = new Dictionary<Vector3Int, List<LightNodeSun>>();
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    public void AddRGBLightNode (Vector3Int chunkPosition, ushort nodeIndex, byte red, byte green, byte blue) {

        List<LightNodeRGB> list;
        if (RGBLightNodes.TryGetValue(chunkPosition, out list)) {

            LightNodeRGB node = new LightNodeRGB {
                index = nodeIndex,
                red = red,
                blue = blue,
                green = green
            };

            list.Add(node);
            return;
        } else {

            list = new List<LightNodeRGB>();

            LightNodeRGB node = new LightNodeRGB {
                index = nodeIndex,
                red = red,
                blue = blue,
                green = green
            };

            list.Add(node);
            RGBLightNodes.Add(chunkPosition, list);
        }
    }

    public void AddSunlightNode (Vector3Int chunkPosition, ushort nodeIndex, byte sun) {

        List<LightNodeSun> list;
        if (SunLightNodes.TryGetValue(chunkPosition, out list)) {

            LightNodeSun node = new LightNodeSun {
                index = nodeIndex,
                sun = sun
            };

            list.Add(node);
            return;
        } else {

            list = new List<LightNodeSun>();

            LightNodeSun node = new LightNodeSun {
                index = nodeIndex,
                sun = sun
            };

            list.Add(node);
            SunLightNodes.Add(chunkPosition, list);
        }
    }

    public bool GetSunlightNodes (Vector3Int chunkPosition, out List<LightNodeSun> nodes) {

        return SunLightNodes.TryGetValue(chunkPosition, out nodes);
    }
}

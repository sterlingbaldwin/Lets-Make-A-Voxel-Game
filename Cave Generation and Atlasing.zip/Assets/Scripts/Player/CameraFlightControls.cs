﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFlightControls : MonoBehaviour {

    enum WorldInteractionMode {
        BreakBlock = 1,
        PlaceBlock = 2,
        PlaceAI = 3,
        MoveAI = 4,
    };

    WorldInteractionMode interactionMode;
    int interactionModeCounter;


    public GameObject raycastPositioningTest;



    public Vector3Int entityStartPosition;
    public Vector3Int entityGoalPosition;




    public GameObject entityGO;
    Entity entityScript;

    public float moveSpeed = 2f;
    public float mouseSensitivity = 5f;

    public KeyCode fastKey = KeyCode.LeftShift;
    bool lockCursor = true;

    float yaw = 0.0f;
    float pitch = 0.0f;

	// Use this for initialization
	void Start () {

        interactionModeCounter = 0;
        interactionMode = WorldInteractionMode.BreakBlock;
        Debug.Log("Interaction mode default to: " + interactionMode);

        UpdateCursorLockState();
	}
	
	// Update is called once per frame
	void Update () {

        float dt = Time.deltaTime;

        if (lockCursor == true) {
            RotateCameraMouse(dt);
            MoveCameraWASD(dt);
            CycleThroughInteractionModes();
            CheckRaycastLocation();
            InteractWithWorld();
        }

        UpdateCursorLockState();
    }

    void UpdateCursorLockState () {

        if (Input.GetKeyDown(KeyCode.Escape)) lockCursor = false;
        if (Input.GetMouseButtonDown(0)) lockCursor = true;

        Cursor.lockState = lockCursor? CursorLockMode.Locked : CursorLockMode.None;
    }

    void RotateCameraMouse (float dt) {

        float mouseX = Input.GetAxis("Mouse X");
        float mouseY = Input.GetAxis("Mouse Y");

        yaw += mouseSensitivity * mouseX;
        pitch -= mouseSensitivity * mouseY;

        transform.eulerAngles = new Vector3(pitch, yaw, 0f);

    }

    void MoveCameraWASD (float dt) {

        if (Input.GetKey(KeyCode.W)) {

            transform.Translate(Vector3.forward * dt * moveSpeed * (Input.GetKey(fastKey) ? 2f : 1f));
        }

        if (Input.GetKey(KeyCode.S)) {

            transform.Translate(-1 * Vector3.forward * dt * moveSpeed * (Input.GetKey(fastKey) ? 2f : 1f));
        }

        if (Input.GetKey(KeyCode.D)) {

            transform.Translate(Vector3.right * dt * moveSpeed * (Input.GetKey(fastKey) ? 2f : 1f));
        }

        if (Input.GetKey(KeyCode.A)) {

            transform.Translate(-1 * Vector3.right * dt * moveSpeed * (Input.GetKey(fastKey) ? 2f : 1f));
        }
    }

    void CycleThroughInteractionModes () {
        
        if (Input.GetKeyDown(KeyCode.Z)) {

            interactionModeCounter = interactionModeCounter - 1;
            if (interactionModeCounter < 1) interactionModeCounter = 4;

            interactionMode = (WorldInteractionMode)interactionModeCounter;

            Debug.Log("Set interaction mode to: " + interactionMode);
        }
        if (Input.GetKeyDown(KeyCode.X)) {
            interactionModeCounter = (interactionModeCounter + 1) % 5;
            if (interactionModeCounter < 1) interactionModeCounter = 1;

            interactionMode = (WorldInteractionMode)interactionModeCounter;
            Debug.Log("Set interaction mode to: " + interactionMode);
        }

    }

    void CheckRaycastLocation () {

        bool adj = !Input.GetKey(KeyCode.Space);

        RaycastHit hit;
        if (Physics.Raycast(transform.position, transform.forward, out hit)) {

            Vector3Int hitPointInt = Manager.gameManager.worldMgr.GetBlockPositionFromRaycast(hit.point, hit.normal, getAdjacent: adj);

            raycastPositioningTest.transform.position = new Vector3() {
                x = hitPointInt.x,
                y = hitPointInt.y,
                z = hitPointInt.z
            };
        }
    }

    void InteractWithWorld () {

        if (Input.GetMouseButtonDown(0)) {

            RaycastHit hit;
            if (Physics.Raycast(transform.position, transform.forward, out hit)) {

                Vector3Int hitPointInt = Manager.gameManager.worldMgr.GetBlockPositionFromRaycast(hit.point, hit.normal, getAdjacent: true);
                Manager.gameManager.worldMgr.SetBlockAt(hitPointInt.x, hitPointInt.y, hitPointInt.z, 0x10);

            }
        }

    }









}

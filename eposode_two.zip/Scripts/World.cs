﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class World : MonoBehaviour
{

    public static World instance;

    public static Matrix4x4 id = Matrix4x4.identity;
    
    public Material material;
    public Texture texture;

    Dictionary <Vector3Int, Chunk> chunkPosMap;
    public int radius = 3;
    public int height = 1;

    void Awake(){

        TextureController.Initialize("", texture);
        chunkPosMap = new Dictionary<Vector3Int, Chunk>();
        instance = this;
    }
    void Start() {
        // Debug.Log("starting up");
            // Debug.Log("creating layer " + y + " of " + height);
        for(int x = -radius; x < radius + 1; x++){
            for(int y = 0; y < height; y++){
                for(int z = -radius; z < radius + 1; z++){
                    
                    Vector3Int pos = new Vector3Int(x * Chunk.size.x, y * Chunk.size.y, z * Chunk.size.z);
                    // Debug.Log("Creating chunk at " + pos);
                    Chunk chunk = new Chunk(new Vector3Int(x * Chunk.size.x, y * Chunk.size.y, z * Chunk.size.z));
                    chunk.GenerateBlockArray();
                    chunkPosMap.Add(chunk.position, chunk);
                }
            }
        }

        foreach(Chunk ch in chunkPosMap.Values){
            StartCoroutine(ch.GenerateMesh());
        }
    }
    void Update(){
        foreach(Chunk ch in chunkPosMap.Values){
            if(ch != null && ch.ready){
                Graphics.DrawMesh(ch.mesh, id, material, 0);
            }
        }
    }

    public bool GetChunkAt(int x, int y, int z, out Chunk chunk){
        Vector3Int key = WorldToChunkCoords(x, y, z);
        return chunkPosMap.TryGetValue(key, out chunk);
    }
    public static Vector3Int WorldToChunkCoords(int x, int y, int z){
        return new Vector3Int(
            Mathf.FloorToInt(x / (float)Chunk.size.x) * Chunk.size.x,
            Mathf.FloorToInt(y / (float)Chunk.size.y) * Chunk.size.y,
            Mathf.FloorToInt(z / (float)Chunk.size.z) * Chunk.size.z
        );
    }
}

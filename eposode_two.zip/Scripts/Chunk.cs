﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Chunk {

    public static Vector3Int size = new Vector3Int(16, 32, 16);
    public Block[] blocks;
    
    public Mesh mesh;
    public Vector3Int position;
    public bool ready = false;
    
    bool printed = false;

    public Chunk(Vector3Int pos) {
        position = pos;
    }
    public void GenerateBlockArray(){
        blocks = new Block[size.x * size.y * size.z];
        int index = 0;
        int value;

        for(int x = 0; x < size.x; x++){
            for(int y = 0; y < size.y; y++){
                for(int z = 0; z < size.z; z++){
                    
                    value = Mathf.CeilToInt (Mathf.PerlinNoise( (x + position.x) / 32f , (z + position.z) / 32f ) * 15f + 2f);
                    
                    // Debug.Log(y);
                    if((position.y + y) > value){
                        index++;
                        continue;
                    }
                    if((position.y + y) == value){
                        if(!printed){
                            Debug.Log("at: " + position);
                            printed = true;
                        }
                        blocks[index] = Block.Grass;
                    }
                    if((position.y + y) < value && (position.y + y) > value - 3){
                        blocks[index] = Block.Dirt;
                    }
                    if((position.y + y) <= value - 3){
                        blocks[index] = Block.Stone;
                    }
                    index++;
                }
            }
        }
    }
    public IEnumerator GenerateMesh(){
        MeshBuilder builder = new MeshBuilder(position, blocks);
        builder.Start();
        yield return new WaitUntil(() => builder.Update() );

        mesh = builder.GetMesh(ref mesh);
        ready = true;

        builder = null;
    }
    public Block GetBlockAt(int x, int y, int z){
        x -= position.x;
        y -= position.y;
        z -= position.z;

        if(IsPointInBounds(x, y, z)){
            return blocks[x * Chunk.size.y * Chunk.size.z + y * Chunk.size.z + z];
        }

        return Block.Air;

    }
    bool IsPointInBounds(int x, int y, int z){
        return x >= 0 && y >= 0 && z >= 0 && x < Chunk.size.x && y < Chunk.size.y && z < Chunk.size.z;
    }
}

﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class TextureController {

    public static Dictionary <string, Vector2[]> textureMap = new Dictionary<string, Vector2[]>();

    public static void Initialize(string texturePath, Texture texture){

        Sprite[] sprites = Resources.LoadAll<Sprite> (texturePath);
        
        foreach(Sprite s in sprites){
            
            // Debug.Log("Loading " + s.name);
            Vector2[] uvs = new Vector2[4];
            uvs[0] = new Vector2(s.rect.xMin / texture.width, s.rect.yMin / texture.height);
            uvs[1] = new Vector2(s.rect.xMax / texture.width, s.rect.yMin / texture.height);
            uvs[2] = new Vector2(s.rect.xMin / texture.width, s.rect.yMax / texture.height);
            uvs[3] = new Vector2(s.rect.xMax / texture.width, s.rect.yMax / texture.height);

            try {
                textureMap.Add(s.name, uvs);
            }
            catch(ArgumentException){
                // Debug.Log("Sprite " + s.name + " already loaded");
            }
        }
    }

    public static bool AddTextures(Block block, Direction dir, int index, Vector2[] uvs) {

        string key = FastGetKey(block, dir);
        Vector2[] text;
        if(textureMap.TryGetValue(key, out text)){

            uvs[index] = text[0];
            uvs[index + 1] = text[1];
            uvs[index + 2] = text[2];
            uvs[index + 3] = text[3];
            return true;
        }

        text = textureMap["default"];
        uvs[index] = text[0];
        uvs[index + 1] = text[1];
        uvs[index + 2] = text[2];
        uvs[index + 3] = text[3];
        return false;
    }

    static string FastGetKey(Block block, Direction direction){

        if(block == Block.Stone){
            return "stone_side";
        }
        if(block == Block.Dirt){
            return "grass_down";
        }
        if(block == Block.Grass){
            if(direction == Direction.Up){
                return "grass_up";
            }
            if(direction == Direction.Down){
                return "grass_down";
            }
            return "grass_side";
        }

        return "default";
    }
    
}

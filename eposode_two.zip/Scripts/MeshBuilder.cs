﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


class MeshBuilder : ThreadedProcess {

    byte[] faces = new byte[Chunk.size.x * Chunk.size.y * Chunk.size.z];

    Vector3[] vertices;
    Vector2[] uvs;
    int [] triangles ;
    Vector3Int position;
    Block[] blocks;

    int sizeEstimate = 0;
    int vertexIndex = 0;
    int trianglesIndex = 0;
    bool isVisible = false;

    public MeshBuilder(Vector3Int pos, Block[] blocks){
        this.position = pos;
        this.blocks = blocks;
    }

    protected override void ThreadFunction() {

        int idx = 0;

        Chunk[] neighbors = new Chunk[6];
        bool[] exists = new bool[6];

        exists[0] = World.instance.GetChunkAt (position.x, position.y, position.z + Chunk.size.z, out neighbors[0]);
        exists[1] = World.instance.GetChunkAt (position.x + Chunk.size.x, position.y, position.z, out neighbors[1]);
        exists[2] = World.instance.GetChunkAt (position.x, position.y, position.z - Chunk.size.z, out neighbors[2]);
        exists[3] = World.instance.GetChunkAt (position.x - Chunk.size.x, position.y, position.z, out neighbors[3]);
        exists[4] = World.instance.GetChunkAt (position.x, position.y + Chunk.size.y, position.z, out neighbors[4]);
        exists[5] = World.instance.GetChunkAt (position.x, position.y - Chunk.size.y, position.z, out neighbors[5]);
 
        for (int x = 0; x < Chunk.size.x; x++) {
            for (int y = 0; y < Chunk.size.y; y++) {
                for (int z = 0; z < Chunk.size.z; z++) {

                    if(blocks[idx].IsTransparent()){
                        faces[idx] = 0;
                        idx++;
                        continue;
                    }
                    if(z == 0 && (exists[2] == false || neighbors[2].GetBlockAt(position.x + x, position.y + y, position.z + z - 1 ) == Block.Air)){
                        faces[idx] |= (byte)Direction.South;
                        sizeEstimate += 4;
                    } else if (z > 0 && blocks[idx - 1] == Block.Air) {
                        faces[idx] |= (byte)Direction.South;
                        sizeEstimate += 4;
                    }

                    if(z == Chunk.size.z - 1 && (exists[0] == false || neighbors[0].GetBlockAt(position.x + x, position.y + y, position.z + z + 1 ) == Block.Air)){
                        faces[idx] |= (byte)Direction.North;
                        sizeEstimate += 4;
                    } else if (z > Chunk.size.z - 1 && blocks[idx + 1] == Block.Air){
                        faces[idx] |= (byte)Direction.North;
                        sizeEstimate += 4;
                    }

                    if(y == 0 && (exists[5] == false || neighbors[5].GetBlockAt(position.x + x, position.y + y - 1, position.z + z) == Block.Air)){
                        faces[idx] |= (byte)Direction.Down;
                        sizeEstimate += 4;
                    } else if (y > 0 && blocks[idx - Chunk.size.z] == Block.Air){
                        faces[idx] |= (byte)Direction.Down;
                        sizeEstimate += 4;
                    }

                    if(y == Chunk.size.y - 1 && (exists[4] == false || neighbors[4].GetBlockAt(position.x + x, position.y + y + 1, position.z + z) == Block.Air)){
                        faces[idx] |= (byte)Direction.Up;
                        sizeEstimate += 4;
                    } else if ( y < Chunk.size.y - 1 && blocks[idx + Chunk.size.z] == Block.Air){
                        faces[idx] |= (byte)Direction.Up;
                        sizeEstimate += 4; 
                    }

                    if(x == 0 && (exists[3] == false || neighbors[3].GetBlockAt(position.x + x - 1, position.y + y, position.z + z) == Block.Air)){
                        faces[idx] |= (byte)Direction.West;
                        sizeEstimate += 4;
                    } else if (x > 0 && blocks[idx - Chunk.size.z * Chunk.size.y] == Block.Air){
                        faces[idx] |= (byte)Direction.West;
                        sizeEstimate += 4;
                    }

                    if(x == Chunk.size.x - 1 && (exists[1] == false || neighbors[1].GetBlockAt(position.x + x + 1, position.y + y, position.z + z) == Block.Air)){
                        faces[idx] |= (byte)Direction.East;
                        sizeEstimate += 4;
                    } else if (x < Chunk.size.x - 1 && blocks[idx + Chunk.size.z * Chunk.size.y] == Block.Air){
                        faces[idx] |= (byte)Direction.East;
                        sizeEstimate += 4;
                    }
                    isVisible = true;
                    idx++;
                }
            }
        }

        if(!isVisible){
            return;
        }

        idx = 0;
        vertices = new Vector3[sizeEstimate];
        uvs = new Vector2[sizeEstimate];
        triangles  = new int[(int)(sizeEstimate * 1.5f)];

        for (int x = 0; x < Chunk.size.x; x++) {
            for (int y = 0; y < Chunk.size.y; y++) {
                for (int z = 0; z < Chunk.size.z; z++) {
                    if(faces[idx] == 0){
                        idx++;
                        continue;
                    }
                    if((faces[idx] & (byte)Direction.North) != 0){
                        
                        vertices[vertexIndex] = new Vector3(x + position.x, y + position.y, z + position.z + 1);
                        vertices[vertexIndex + 1] = new Vector3(x + position.x + 1, y + position.y, z + position.z + 1);
                        vertices[vertexIndex + 2] = new Vector3(x + position.x, y + position.y + 1, z + position.z + 1);
                        vertices[vertexIndex + 3] = new Vector3(x + position.x + 1, y + position.y + 1, z + position.z + 1);

                        triangles [trianglesIndex] = vertexIndex + 1;
                        triangles [trianglesIndex + 1] = vertexIndex + 2;
                        triangles [trianglesIndex + 2] = vertexIndex;

                        triangles [trianglesIndex + 3] = vertexIndex + 1;
                        triangles [trianglesIndex + 4] = vertexIndex + 3;
                        triangles [trianglesIndex + 5] = vertexIndex + 2;

                        TextureController.AddTextures (blocks[idx], Direction.North, vertexIndex, uvs);
                        
                        vertexIndex += 4;
                        trianglesIndex += 6;
                    }
                    if((faces[idx] & (byte)Direction.East) != 0){
                        
                        vertices[vertexIndex] = new Vector3(x + position.x + 1, y + position.y, z + position.z);
                        vertices[vertexIndex + 1] = new Vector3(x + position.x + 1, y + position.y, z + position.z + 1);
                        vertices[vertexIndex + 2] = new Vector3(x + position.x + 1, y + position.y + 1, z + position.z);
                        vertices[vertexIndex + 3] = new Vector3(x + position.x + 1, y + position.y + 1, z + position.z + 1);

                        triangles [trianglesIndex] = vertexIndex;
                        triangles [trianglesIndex + 1] = vertexIndex + 2;
                        triangles [trianglesIndex + 2] = vertexIndex + 1;

                        triangles [trianglesIndex + 3] = vertexIndex + 2;
                        triangles [trianglesIndex + 4] = vertexIndex + 3;
                        triangles [trianglesIndex + 5] = vertexIndex + 1;

                        TextureController.AddTextures (blocks[idx], Direction.East, vertexIndex, uvs);
                        
                        vertexIndex += 4;
                        trianglesIndex += 6;
                    }
                    if((faces[idx] & (byte)Direction.South) != 0){
                        
                        vertices[vertexIndex] = new Vector3(x + position.x, y + position.y, z + position.z);
                        vertices[vertexIndex + 1] = new Vector3(x + position.x + 1, y + position.y, z + position.z);
                        vertices[vertexIndex + 2] = new Vector3(x + position.x, y + position.y + 1, z + position.z);
                        vertices[vertexIndex + 3] = new Vector3(x + position.x + 1, y + position.y + 1, z + position.z);

                        triangles [trianglesIndex] = vertexIndex;
                        triangles [trianglesIndex + 1] = vertexIndex + 2;
                        triangles [trianglesIndex + 2] = vertexIndex + 1;

                        triangles [trianglesIndex + 3] = vertexIndex + 2;
                        triangles [trianglesIndex + 4] = vertexIndex + 3;
                        triangles [trianglesIndex + 5] = vertexIndex + 1;

                        TextureController.AddTextures (blocks[idx], Direction.South, vertexIndex, uvs);
                        
                        vertexIndex += 4;
                        trianglesIndex += 6;
                    }
                    if((faces[idx] & (byte)Direction.West) != 0){
                        
                        vertices[vertexIndex] = new Vector3(x + position.x, y + position.y, z + position.z);
                        vertices[vertexIndex + 1] = new Vector3(x + position.x, y + position.y, z + position.z + 1);
                        vertices[vertexIndex + 2] = new Vector3(x + position.x, y + position.y + 1, z + position.z);
                        vertices[vertexIndex + 3] = new Vector3(x + position.x, y + position.y + 1, z + position.z + 1);

                        triangles [trianglesIndex] = vertexIndex + 1;
                        triangles [trianglesIndex + 1] = vertexIndex + 2;
                        triangles [trianglesIndex + 2] = vertexIndex;

                        triangles [trianglesIndex + 3] = vertexIndex + 1;
                        triangles [trianglesIndex + 4] = vertexIndex + 3;
                        triangles [trianglesIndex + 5] = vertexIndex + 2;

                        TextureController.AddTextures (blocks[idx], Direction.West, vertexIndex, uvs);
                        
                        vertexIndex += 4;
                        trianglesIndex += 6;
                    }
                    if((faces[idx] & (byte)Direction.Up) != 0){
                        
                        vertices[vertexIndex] = new Vector3(x + position.x, y + position.y + 1, z + position.z);
                        vertices[vertexIndex + 1] = new Vector3(x + position.x + 1, y + position.y + 1, z + position.z);
                        vertices[vertexIndex + 2] = new Vector3(x + position.x, y + position.y + 1, z + position.z + 1);
                        vertices[vertexIndex + 3] = new Vector3(x + position.x + 1, y + position.y + 1, z + position.z + 1);

                        triangles [trianglesIndex] = vertexIndex;
                        triangles [trianglesIndex + 1] = vertexIndex + 2;
                        triangles [trianglesIndex + 2] = vertexIndex + 1;

                        triangles [trianglesIndex + 3] = vertexIndex + 2;
                        triangles [trianglesIndex + 4] = vertexIndex + 3;
                        triangles [trianglesIndex + 5] = vertexIndex + 1;

                        TextureController.AddTextures (blocks[idx], Direction.Up, vertexIndex, uvs);
                        
                        vertexIndex += 4;
                        trianglesIndex += 6;
                    }
                    if((faces[idx] & (byte)Direction.Down) != 0){
                        
                        vertices[vertexIndex] = new Vector3(x + position.x, y + position.y, z + position.z);
                        vertices[vertexIndex + 1] = new Vector3(x + position.x, y + position.y, z + position.z + 1);
                        vertices[vertexIndex + 2] = new Vector3(x + position.x + 1, y + position.y, z + position.z);
                        vertices[vertexIndex + 3] = new Vector3(x + position.x + 1, y + position.y, z + position.z + 1);

                        triangles [trianglesIndex] = vertexIndex;
                        triangles [trianglesIndex + 1] = vertexIndex + 2;
                        triangles [trianglesIndex + 2] = vertexIndex + 1;

                        triangles [trianglesIndex + 3] = vertexIndex + 2;
                        triangles [trianglesIndex + 4] = vertexIndex + 3;
                        triangles [trianglesIndex + 5] = vertexIndex + 1;

                        TextureController.AddTextures (blocks[idx], Direction.Down, vertexIndex, uvs);
                        
                        vertexIndex += 4;
                        trianglesIndex += 6;
                    }
                    idx++;
                }
            }
        }
    }

    public Mesh GetMesh (ref Mesh copy){
        if(copy == null){
            copy = new Mesh();
        } else {
            copy.Clear();
        }

        if(isVisible == false || vertexIndex == 0){
            return copy;
        }
        // if(vertexIndex > 65000){
        //     copy.IndexFormat = UnityEngine.Rendering.IndexFormat.UInt32;
        // }
        copy.vertices = vertices;
        copy.uv = uvs;
        copy.triangles  = triangles;

        copy.RecalculateNormals();
        return copy;
    }
}

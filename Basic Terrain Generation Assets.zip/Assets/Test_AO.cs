﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Test_AO : MonoBehaviour {

    public bool topLeft;
    public bool topRight;
    public bool bottomLeft;
    public bool bottomRight;

	// Use this for initialization
	void Start () {

        MeshData md = new MeshData(4, 1);
        md.AddFaceDataWithAO(
            new Vector3[] { new Vector3(-0.5f, -0.5f, -0.5f), new Vector3(0.5f, -0.5f, -0.5f), new Vector3(-0.5f, 0.5f, -0.5f), new Vector3(0.5f, 0.5f, -0.5f) },
            new Vector2[] { Vector2.zero, Vector2.right, Vector2.up, Vector2.one },
            new Color[] { Color.white, Color.white, Color.white, Color.white },
            Vector3.back,
            new Vector4(0f, 0f, 0f, 0f),
            new int[] { 0, 2, 1, 2, 3, 1, },
            0,
            new bool[] { bottomLeft, bottomRight, topLeft, topRight },
            new Vector3Int(0, 0, 0)
        );

        GetComponent<MeshFilter>().mesh = md.ToMesh();

	}
	
	// Update is called once per frame
	void Update () {
		
	}
}

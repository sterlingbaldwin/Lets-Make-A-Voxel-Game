﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public partial class ThreadManager {

    class LightBuilder : ThreadedProcess {

        static Queue<LightDataArray> lightDataQueue = new Queue<LightDataArray>();

        LightDataArray array;
        Chunk chunk;
        

        public LightBuilder (Chunk chunk) {

            this.chunk = chunk;
        }

        public override void Start() {

            array = lightDataQueue.Count > 0 ? lightDataQueue.Dequeue() : new LightDataArray(Chunk.size);
            base.Start();
        }

        protected override void ThreadFunction() {

            int idx = 0;
            for (int x = 0; x < Chunk.size; x++) {
                for (int y = 0; y < Chunk.size; y++) {
                    for (int z = 0; z < Chunk.size; z++) {

                        array.red[idx] = 255;
                        array.green[idx] = 255;
                        array.blue[idx] = 255;
                        array.sun[idx] = 255;

                        idx++;
                    }
                }
            }
        }

        protected override void OnFinished() {

            lightDataQueue.Enqueue(array);
            chunk.OnLightDataFinished(array.red, array.green, array.blue, array.sun);
        }
    }
}
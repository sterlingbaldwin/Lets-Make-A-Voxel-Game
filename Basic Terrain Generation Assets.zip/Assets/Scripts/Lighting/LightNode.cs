﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LightNodeSun {

    public byte sun;
    public int index;
}

public class LightNodeRGB {

    public byte red, green, blue;
    public int index;
}

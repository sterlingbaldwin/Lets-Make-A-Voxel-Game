﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class BlockExtensions {

    public static bool CanSeeSide (this Block block, Block neighbor, Vector3Int direction) {

        if (block.value == 0x00) return false;
        if (neighbor.value == 0x00) return true;

        //Proceeds to volmit
        BlockData blockData = BlockManager.GetBlockData(block.value & ~0xF);
        BlockData neighborData = BlockManager.GetBlockData(block.value & ~0xF);

        if (blockData.shapeID == 0 && neighborData.shapeID == 0) return false;

        return true;
    }
}

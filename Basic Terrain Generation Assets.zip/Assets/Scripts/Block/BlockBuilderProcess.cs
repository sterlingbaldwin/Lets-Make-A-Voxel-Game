﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public partial class ThreadManager {

    public class BlockBuilder : ThreadedProcess {

        Chunk chunk;
        Block[] blocks;
        List<int> lightSourceIndices;
        bool isAir;

        public BlockBuilder (Chunk chunk) {

            this.chunk = chunk;
        }

        protected override void ThreadFunction() {
            //NOTE: For now, block id 0 = Air, id 1 = Filled, id 2 = LightSource

            isAir = true;
            lightSourceIndices = new List<int>();
            blocks = new Block[Chunk.size * Chunk.size * Chunk.size];
            
            int idx = 0;
            for (int x = 0; x < Chunk.size; x++) {
                for (int y = 0; y < Chunk.size; y++) {
                    for (int z = 0; z < Chunk.size; z++) {

                        float height = Mathf.PerlinNoise((x + chunk.position.x) / 64f + 756, (z + chunk.position.z) / 64f) * 16f
                            + Mathf.PerlinNoise((x + chunk.position.x) / 16f - 5778, (z + chunk.position.z) / 16f +78) * 4f
                            + Mathf.PerlinNoise((x + chunk.position.x) / 256f, (z + chunk.position.z) / 256f + 567) * 96f
                            + Mathf.PerlinNoise((x + chunk.position.x) / 128f - 7798, (z + chunk.position.z) / 64f +120) * 48f
                            + Mathf.PerlinNoise((x + chunk.position.x) / 64f, (z + chunk.position.z) / 96f + 4800) * 32f
                            + Mathf.PerlinNoise((x + chunk.position.x) / 256f + 846, (z + chunk.position.z) / 128f + 12) * 72f;

                        if (y + chunk.position.y < height) {

                            blocks[idx].value = 0x10;
                            isAir = false;
                        }

                        idx++;
                    }
                }
            }
        }

        protected override void OnFinished() {

            chunk.OnBlockDataFinished(blocks, lightSourceIndices, isAir);
        }
    }
}


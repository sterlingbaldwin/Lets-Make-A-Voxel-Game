﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public struct Block {

    public static readonly int MetadataMask = 0xF0;
    public static readonly int RotationMask = 0x0F;
    public static readonly int BlockIDMask = ~(0xFF);

    public int value;

    public static Block Air = new Block() { value = 0x00 };
    public static Block Utility_Skip = new Block() { value = 0x01 };

}

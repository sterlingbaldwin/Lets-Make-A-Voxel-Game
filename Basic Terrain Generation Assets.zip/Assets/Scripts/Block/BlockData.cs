﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlockData {

    public string name;
    public int shapeID;
}

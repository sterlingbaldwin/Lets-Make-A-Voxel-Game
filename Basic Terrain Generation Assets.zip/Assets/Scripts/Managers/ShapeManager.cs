﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShapeManager : Manager {

    public static Shape[] shapes;

	// Use this for initialization
	public override void Start () {

        LoadShapes();
	}
	
    void LoadShapes () {

        List<string[]> shapeFiles = FilePathLibrary.GetAllFileDataInDirectory(FilePathLibrary.shapeDataPath);
        shapes = new Shape[shapeFiles.Count];

        for (int i = 0; i < shapeFiles.Count; i++) {
            ParseShapeFile(shapeFiles[i]);
        }
    }

    void ParseShapeFile (string[] data) {

        int id = int.Parse(data[0]);


        Dictionary<Direction, List<Vector3>> vertices = new Dictionary<Direction, List<Vector3>>();
        Dictionary<Direction, List<Vector2>> uvs = new Dictionary<Direction, List<Vector2>>();
        Dictionary<Direction, List<int>> triangles = new Dictionary<Direction, List<int>>();
        Dictionary<Direction, Vector3> normals = new Dictionary<Direction, Vector3>();
        Dictionary<Direction, Vector4> tangents = new Dictionary<Direction, Vector4>();

        Direction currentSide = Direction.North;

        for (int i = 0; i < data.Length; i++) {

            if (data[i] == "North") {
                currentSide = Direction.North;
                vertices.Add(Direction.North, new List<Vector3>());
                uvs.Add(Direction.North, new List<Vector2>());
                triangles.Add(Direction.North, new List<int>());
            }
            if (data[i] == "East") {
                currentSide = Direction.East;
                vertices.Add(Direction.East, new List<Vector3>());
                uvs.Add(Direction.East, new List<Vector2>());
                triangles.Add(Direction.East, new List<int>());
            }
            if (data[i] == "South") {
                currentSide = Direction.South;
                vertices.Add(Direction.South, new List<Vector3>());
                uvs.Add(Direction.South, new List<Vector2>());
                triangles.Add(Direction.South, new List<int>());
            }
            if (data[i] == "West") {
                currentSide = Direction.West;
                vertices.Add(Direction.West, new List<Vector3>());
                uvs.Add(Direction.West, new List<Vector2>());
                triangles.Add(Direction.West, new List<int>());
            }
            if (data[i] == "Up") {
                currentSide = Direction.Up;
                vertices.Add(Direction.Up, new List<Vector3>());
                uvs.Add(Direction.Up, new List<Vector2>());
                triangles.Add(Direction.Up, new List<int>());
            }
            if (data[i] == "Down") {
                currentSide = Direction.Down;
                vertices.Add(Direction.Down, new List<Vector3>());
                uvs.Add(Direction.Down, new List<Vector2>());
                triangles.Add(Direction.Down, new List<int>());
            }

            if (data[i].Contains("v: ")) {
                string[] vertex = data[i].Split(' ');
                vertices[currentSide].Add(
                    new Vector3(
                        float.Parse(vertex[1]) - 0.5f,
                        float.Parse(vertex[2]) - 0.5f,
                        float.Parse(vertex[3]) - 0.5f
                    )
                );
            }

            if (data[i].Contains("u: ")) {

                string[] uv = data[i].Split(' ');
                uvs[currentSide].Add(
                    new Vector2(
                        float.Parse(uv[1]),
                        float.Parse(uv[2])
                    )
                );
            }

            if (data[i].Contains("n: ")) {

                string[] normal = data[i].Split(' ');
                normals[currentSide] = new Vector3(
                    float.Parse(normal[1]),
                    float.Parse(normal[2]),
                    float.Parse(normal[3])
                );
            }

            if (data[i].Contains("ta: ")) {

                string[] tangent = data[i].Split(' ');
                tangents[currentSide] = new Vector4(
                    float.Parse(tangent[1]),
                    float.Parse(tangent[2]),
                    float.Parse(tangent[3]),
                    float.Parse(tangent[4])
                );
            }

            if (data[i].Contains("t: ")) {

                string[] tris = data[i].Split(' ');
                for (int j = 1; j < tris.Length; j++) {

                    triangles[currentSide].Add(
                        int.Parse(tris[j])
                    );
                }
            }
        }

        Shape shape = new Shape();

        for (int i = 0; i < 6; i++) {

            Direction dir = (Direction)(0x01 << i);

            shape.AddFaceData(
                dir,
                vertices[dir].ToArray(),
                uvs[dir].ToArray(),
                triangles[dir].ToArray(),
                normals[dir],
                tangents[dir]
            );
        }

        shapes[id] = shape;
    }
}

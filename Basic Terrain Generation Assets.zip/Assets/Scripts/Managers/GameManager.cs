﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour {

    public bool enableThreading;

    public int chunksTall = 10, radius = 2;
    public Material material;


    public BlockManager blockMgr;
    public StructureManager structureMgr;
    public ShapeManager shapeMgr;
    public TextureAndMaterialManager textureAndMaterialMgr;

    public ThreadManager threadMgr;
    public WorldManager worldMgr;

	// Use this for initialization
	void Start () {

        ThreadedProcess.enableThreading = enableThreading;

        ConstructManagers();
        StartManagers();
	}
	
	// Update is called once per frame
	void Update () {

        UpdateManagers(Time.deltaTime);
	}

    void ConstructManagers () {

        blockMgr = new BlockManager();
        structureMgr = new StructureManager();
        shapeMgr = new ShapeManager();
        textureAndMaterialMgr = new TextureAndMaterialManager();

        threadMgr = new ThreadManager();
        worldMgr = new WorldManager(chunksTall, radius);
    }

    void StartManagers () {

        blockMgr.Start();
        structureMgr.Start();
        shapeMgr.Start();
        textureAndMaterialMgr.Start();

        threadMgr.Start();
        worldMgr.Start();
    }

    void UpdateManagers (float dt) {

        threadMgr.Update(dt);
        worldMgr.Update(dt);
    }
}

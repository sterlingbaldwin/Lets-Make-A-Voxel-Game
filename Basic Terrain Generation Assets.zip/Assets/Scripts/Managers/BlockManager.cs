﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlockManager : Manager {

    public static Dictionary<int, BlockData> blockDataMap;


    public BlockManager () {

    }

    public override void Start () {

        LoadBlocks();
    }

    void LoadBlocks () {

        blockDataMap = new Dictionary<int, BlockData>();
        List<string[]> blockFiles = FilePathLibrary.GetAllFileDataInDirectory(FilePathLibrary.blockDataPath);

        for (int i = 0; i < blockFiles.Count; i++) {
            ParseBlockFile(blockFiles[i]);
        }
    }

    void ParseBlockFile (string[] data) {

        int id = int.Parse(data[0]);
        int shape = int.Parse(data[1]);
        string name = data[2];

        Debug.Log(id + " | " + name);

        blockDataMap.Add(
            id << 4,
            new BlockData() {
                name = name,
                shapeID = shape
            }
        );
    }

    public static BlockData GetBlockData (int id) {

        BlockData data;
        if (blockDataMap.TryGetValue(id, out data)) return data;
        else {
            Debug.Log(id + " does not exist");
            return null;
        }
    }
}

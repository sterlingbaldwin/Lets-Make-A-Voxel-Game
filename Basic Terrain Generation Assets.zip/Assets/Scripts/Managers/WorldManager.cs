﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WorldManager : Manager {

    static float timer;

    public Dictionary<Vector2Int, Chunk[]> chunkColumnMap;
    public List<Chunk> activeChunks;

    public int chunksTall;
    public int radius;

    public WorldManager (int chunksTall = 10, int radius = 1) {

        timer = 0f;

        chunkColumnMap = new Dictionary<Vector2Int, Chunk[]>();
        activeChunks = new List<Chunk>();

        this.chunksTall = chunksTall;
        this.radius = radius;
    }

    // Use this for initialization
    public override void Start () {

        //Note: Do not set this in the constructor.
        Chunk.world = this;

        for (int x = -radius; x <= radius; x++) {
            for (int z = -radius; z <= radius; z++) {

                CreateChunkColumnAt(x * Chunk.size, z * Chunk.size);
            }
        }
	}
	
    public void CreateChunkColumnAt (int x, int z) {

        Vector2Int key = Chunk.WorldCoordinatesToChunkCoordinates(x, z);

        if (chunkColumnMap.ContainsKey(key) == false) {

            Chunk[] column = new Chunk[chunksTall];
            for (int i = 0; i < chunksTall; i++) {
                column[i] = new Chunk(key.x, i * Chunk.size, key.y);
                activeChunks.Add(column[i]);
            }

            chunkColumnMap.Add(key, column);
        }

    }


	// Update is called once per frame
	public override void Update (float dt) {

        timer += dt;
        bool doTick = timer >= (1 / 20f);

        for (int i = 0; i < activeChunks.Count; i++) {

            activeChunks[i].Draw();

            //Is it time to tick?
            if (doTick) {
                //Should this chunk continue ticking
                if (activeChunks[i].Tick() == false) {

                    //if not, sleep
                    activeChunks.RemoveAt(i);
                    i--;
                }
            }
        }

        if (doTick) timer = 0f;
	}

    public void UpdateChunkWorld () {

        Chunk.world = this;
    }

    public Block GetBlockAt (int x, int y, int z) {

        Chunk ch;
        if (GetChunkAt(x, y, z, out ch)) {
            return ch.GetBlockAt(x, y, z);
        }
        return Block.Air;
    }

    public bool GetChunkAt (int x, int y, int z, out Chunk ch) {

        Vector2Int key = Chunk.WorldCoordinatesToChunkCoordinates(x, z);

        Chunk[] column;
        if (chunkColumnMap.TryGetValue(key, out column)) {

            int idx = Mathf.FloorToInt(y / (float)Chunk.size);
            if (idx >= 0 && idx < chunksTall) {
                ch = column[idx];
                return true;
            }
        }

        ch = null;
        return false;
    }
}

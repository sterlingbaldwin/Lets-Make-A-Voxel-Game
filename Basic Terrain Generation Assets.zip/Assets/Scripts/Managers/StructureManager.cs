﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StructureManager : Manager {

    static Dictionary<int, List<StructureNode>> StructureIDMap;



    class StructureNode {

        public StructureNode (Block block, Vector3Int position) {

            this.block = block;
            this.position = position;
        }

        public Block block;
        public Vector3Int position;
    }

	// Use this for initialization
	public override void Start () {

        StructureIDMap = new Dictionary<int, List<StructureNode>>();
        LoadAllStructures();
	}
	
    void LoadAllStructures () {


    }

    public void GenerateStructureAt (int id, Vector3Int position) {


        List<StructureNode> nodes = StructureIDMap[id];

        for (int i = 0; i < nodes.Count; i++) {
            

        }
    }
}

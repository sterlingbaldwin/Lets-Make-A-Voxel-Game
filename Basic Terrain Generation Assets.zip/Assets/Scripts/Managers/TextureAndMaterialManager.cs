﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TextureAndMaterialManager : Manager {

    public Dictionary<string, Vector2[]> textureUVMap;

    Texture2D[] atlases; // albedo, normal, cutout, metallic

	// Use this for initialization
	public override void Start () {

        LoadTextures();
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    void LoadTextures () {


    }
}

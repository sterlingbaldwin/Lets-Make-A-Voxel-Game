﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public partial class ThreadManager {

    class MeshBuilder : ThreadedProcess {

        static Queue<MeshData> meshDataQueue = new Queue<MeshData>();
        static Queue<Shape.Face[]> faceDataQueue = new Queue<Shape.Face[]>();


        Chunk chunk;
        MeshData meshData;
        Shape.Face[] faceData;

        public MeshBuilder(Chunk chunk) {

            this.chunk = chunk;
        }

        public override void Start() {

            //This MUST be done in the main thread. Really bad things happen if it doesn't.
            meshData = meshDataQueue.Count > 0 ? meshDataQueue.Dequeue() : new MeshData(1500000, 1);
            faceData = faceDataQueue.Count > 0 ? faceDataQueue.Dequeue() : new Shape.Face[6];
            base.Start();
        }

        protected override void ThreadFunction() {

            Block[] blocks = chunk.blocks;


            int idx = 0;
            Vector3Int blockPos = chunk.position;


            for (int x = 0; x < Chunk.size; x++) {
                for (int y = 0; y < Chunk.size; y++) {
                    for (int z = 0; z < Chunk.size; z++) {

                        Block current = blocks[idx];
                        if (current.value == 0x00) goto skip;

                        Vector3Int[] lookAt = current.GetLookAtVectors();
                        Direction visibleFaces = 0;

                        for (int j = 0; j < 6; j++) {

                            Block neighbor = chunk.GetBlockAt(blockPos.x + lookAt[j].x, blockPos.y + lookAt[j].y, blockPos.z + lookAt[j].z);
                            if (current.CanSeeSide (neighbor, lookAt[j])) {
                                visibleFaces |= (Direction)(0x01 << j);
                            }
                        }

                        if (visibleFaces == 0) goto skip;

                        BlockData data = BlockManager.GetBlockData(current.value & ~0xF);
                        ShapeManager.shapes[data.shapeID].GetFaces(visibleFaces, faceData);

                        for (int j = 0; j < 6; j++) {

                            if (faceData[j] == null) continue;

                            bool[] ao = new bool[] { false, false, false, false };

                            if (j == 2) ao[0] = true;


                            meshData.AddFaceDataWithAO(
                                faceData[j].vertices,
                                faceData[j].uvs,
                                new Color[] {Color.white, Color.white, Color.white, Color.white},
                                faceData[j].normal,
                                faceData[j].tangent,
                                faceData[j].triangles,
                                0,
                                ao,
                                blockPos
                            );

                        }




                        skip:;

                        idx++;
                        blockPos.z++;
                    }

                    blockPos.z -= Chunk.size;
                    blockPos.y++;
                }

                blockPos.y -= Chunk.size;
                blockPos.x++;
            }




        }

        protected override void OnFinished() {

            Mesh graphics = meshData.ToMesh(clear : true);
            Mesh physics = null;

            chunk.OnMeshDataFinished(graphics, physics);

            meshDataQueue.Enqueue(meshData);
            faceDataQueue.Enqueue(faceData);
        }
    }

}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MeshData {

    public int VertexCount;
    public int[] TriangleCount;

    public Vector3[] vertices;
    public Vector3[] normals;
    public Vector2[] uvs;
    public Vector4[] tangents;
    public Color32[] colors;

    public int[][] triangles;

    public MeshData (int maxVertices, int submeshes) {

        vertices = new Vector3[maxVertices];
        normals = new Vector3[maxVertices];
        uvs = new Vector2[maxVertices];
        tangents = new Vector4[maxVertices];
        colors = new Color32[maxVertices];

        triangles = new int[submeshes][];
        TriangleCount = new int[submeshes];

        for (int i = 0; i < submeshes; i++) {
            triangles[i] = new int[maxVertices * 3 / 2];
        }
    }

    public void AddFaceDataWithAO(Vector3[] inVerts, Vector2[] inUVS, Color[] inColors, Vector3 inNormal, Vector4 inTangent, int[] inTris, int submesh, bool[] ao, Vector3Int offset) {

        int length = inTris.Length;

        for (int i = 0; i < length; i++) {

            this.triangles[submesh][TriangleCount[submesh]] = inTris[i] + VertexCount;
            TriangleCount[submesh]++;
        }

        length = inVerts.Length;

        for (int i = 0; i < length; i++) {
            this.vertices[VertexCount] = inVerts[i];
            this.uvs[VertexCount] = inUVS[i];
            this.colors[VertexCount] = inColors[i];
            this.normals[VertexCount] = inNormal;
            this.tangents[VertexCount] = inTangent;

            VertexCount++;
        }

        // Case 1: BottomLeft or TopRight
        if (ao[0] && !ao[1] && !ao[2] && !ao[3]) {

            this.colors[VertexCount - 4] = Color.black;
            this.colors[VertexCount - 3] = Color.white;
            this.colors[VertexCount - 2] = Color.white;
            this.colors[VertexCount - 1] = Color.white;
        }
        if (!ao[0] && !ao[1] && !ao[2] && ao[3]) {

            this.colors[VertexCount - 4] = Color.white;
            this.colors[VertexCount - 3] = Color.white;
            this.colors[VertexCount - 2] = Color.white;
            this.colors[VertexCount - 1] = Color.black;
        }

        //Case 2: BottomRight or Topleft
        if (!ao[0] && ao[1] && !ao[2] && !ao[3]) {

            this.colors[VertexCount - 4] = Color.black;
            this.colors[VertexCount - 3] = Color.white;
            this.colors[VertexCount - 2] = Color.white;
            this.colors[VertexCount - 1] = Color.white;

            Quaternion q = Quaternion.Euler(0f, 0f, 90f);
            for (int j = 1; j < 5; j++) {

                this.vertices[VertexCount - j] = q * this.vertices[VertexCount - j];
            }

            //Swap UVs
            Vector2 temp = this.uvs[VertexCount - 4];
            this.uvs[VertexCount - 4] = this.uvs[VertexCount - 2];
            this.uvs[VertexCount - 2] = this.uvs[VertexCount - 1];
            this.uvs[VertexCount - 1] = this.uvs[VertexCount - 3];
            this.uvs[VertexCount - 3] = temp;
        }
        if (!ao[0] && !ao[1] && ao[2] && !ao[3]) {

            this.colors[VertexCount - 4] = Color.white;
            this.colors[VertexCount - 3] = Color.white;
            this.colors[VertexCount - 2] = Color.white;
            this.colors[VertexCount - 1] = Color.black;

            Quaternion q = Quaternion.Euler(0f, 0f, 90f);
            for (int j = 1; j < 5; j++) {

                this.vertices[VertexCount - j] = q * this.vertices[VertexCount - j];
            }

            //Swap UVs
            Vector2 temp = this.uvs[VertexCount - 4];
            this.uvs[VertexCount - 4] = this.uvs[VertexCount - 2];
            this.uvs[VertexCount - 2] = this.uvs[VertexCount - 1];
            this.uvs[VertexCount - 1] = this.uvs[VertexCount - 3];
            this.uvs[VertexCount - 3] = temp;
        }

        //Case 3: Straight Line 
        if (ao[0] && ao[1] && !ao[2] && !ao[3]) {

            this.colors[VertexCount - 4] = Color.black;
            this.colors[VertexCount - 3] = Color.black;
            this.colors[VertexCount - 2] = Color.white;
            this.colors[VertexCount - 1] = Color.white;
        }
        if (!ao[0] && !ao[1] && ao[2] && ao[3]) {

            this.colors[VertexCount - 4] = Color.white;
            this.colors[VertexCount - 3] = Color.white;
            this.colors[VertexCount - 2] = Color.black;
            this.colors[VertexCount - 1] = Color.black;
        }
        if (ao[0] && !ao[1] && ao[2] && !ao[3]) {

            this.colors[VertexCount - 4] = Color.black;
            this.colors[VertexCount - 3] = Color.white;
            this.colors[VertexCount - 2] = Color.black;
            this.colors[VertexCount - 1] = Color.white;
        }
        if (!ao[0] && ao[1] && !ao[2] && ao[3]) {

            this.colors[VertexCount - 4] = Color.white;
            this.colors[VertexCount - 3] = Color.black;
            this.colors[VertexCount - 2] = Color.white;
            this.colors[VertexCount - 1] = Color.black;
        }

        // Case 4: 3-Corners
        if (ao[0] && ao[1] && ao[2] && !ao[3]) {

            this.colors[VertexCount - 4] = Color.black;
            this.colors[VertexCount - 3] = Color.black;
            this.colors[VertexCount - 2] = Color.black;
            this.colors[VertexCount - 1] = Color.white;
        }
        if (!ao[0] && ao[1] && ao[2] && ao[3]) {

            this.colors[VertexCount - 4] = Color.white;
            this.colors[VertexCount - 3] = Color.black;
            this.colors[VertexCount - 2] = Color.black;
            this.colors[VertexCount - 1] = Color.black;
        }
        if (!ao[0] && ao[1] && ao[2] && ao[3]) {

            this.colors[VertexCount - 4] = Color.black;
            this.colors[VertexCount - 3] = Color.black;
            this.colors[VertexCount - 2] = Color.black;
            this.colors[VertexCount - 1] = Color.white;

            Quaternion q = Quaternion.Euler(0f, 0f, 90f);
            for (int j = 1; j < 5; j++) {

                this.vertices[VertexCount - j] = q * this.vertices[VertexCount - j];
            }

            //Swap UVs
            Vector2 temp = this.uvs[VertexCount - 4];
            this.uvs[VertexCount - 4] = this.uvs[VertexCount - 2];
            this.uvs[VertexCount - 2] = this.uvs[VertexCount - 1];
            this.uvs[VertexCount - 1] = this.uvs[VertexCount - 3];
            this.uvs[VertexCount - 3] = temp;
        }
        if (ao[0] && ao[1] && !ao[2] && ao[3]) {

            this.colors[VertexCount - 4] = Color.white;
            this.colors[VertexCount - 3] = Color.black;
            this.colors[VertexCount - 2] = Color.black;
            this.colors[VertexCount - 1] = Color.black;

            Quaternion q = Quaternion.Euler(0f, 0f, 90f);
            for (int j = 1; j < 5; j++) {

                this.vertices[VertexCount - j] = q * this.vertices[VertexCount - j];
            }
            //Swap UVs
            Vector2 temp = this.uvs[VertexCount - 4];
            this.uvs[VertexCount - 4] = this.uvs[VertexCount - 2];
            this.uvs[VertexCount - 2] = this.uvs[VertexCount - 1];
            this.uvs[VertexCount - 1] = this.uvs[VertexCount - 3];
            this.uvs[VertexCount - 3] = temp;
        }
        //Case 5: Across Diagonal
        if (ao[0] && !ao[1] && !ao[2] && ao[3]) {

            this.colors[VertexCount - 4] = Color.black;
            this.colors[VertexCount - 3] = Color.white;
            this.colors[VertexCount - 2] = Color.white;
            this.colors[VertexCount - 1] = Color.black;
        }
        if (!ao[0] && ao[1] && ao[2] && !ao[3]) {

            this.colors[VertexCount - 4] = Color.black;
            this.colors[VertexCount - 3] = Color.white;
            this.colors[VertexCount - 2] = Color.white;
            this.colors[VertexCount - 1] = Color.black;


            Quaternion q = Quaternion.Euler(0f, 0f, 90f);
            for (int j = 1; j < 5; j++) {

                this.vertices[VertexCount - j] = q * this.vertices[VertexCount - j];
            }
            //Swap UVs
            Vector2 temp = this.uvs[VertexCount - 4];
            this.uvs[VertexCount - 4] = this.uvs[VertexCount - 2];
            this.uvs[VertexCount - 2] = this.uvs[VertexCount - 1];
            this.uvs[VertexCount - 1] = this.uvs[VertexCount - 3];
            this.uvs[VertexCount - 3] = temp;
        }
        // Case 6: All
        if (ao[0] && ao[1] && ao[2] && ao[3]) {

            this.colors[VertexCount - 4] = Color.black;
            this.colors[VertexCount - 3] = Color.black;
            this.colors[VertexCount - 2] = Color.black;
            this.colors[VertexCount - 1] = Color.black;
        }

        // Case 7: None
        if (!ao[0] && !ao[1] && !ao[2] && !ao[3]) {

            this.colors[VertexCount - 4] = Color.white;
            this.colors[VertexCount - 3] = Color.white;
            this.colors[VertexCount - 2] = Color.white;
            this.colors[VertexCount - 1] = Color.white;
        }

        for (int i = 4; i >= 1; i--) {

            this.vertices[VertexCount - i].x += offset.x;
            this.vertices[VertexCount - i].y += offset.y;
            this.vertices[VertexCount - i].z += offset.z;
        }

    }


    public Mesh ToMesh (bool clear = false) {

        Vector3[] vertices;
        Vector3[] normals;
        Vector2[] uvs;
        Vector4[] tangents;
        Color32[] colors;

        vertices = new Vector3[VertexCount];
        normals = new Vector3[VertexCount];
        uvs = new Vector2[VertexCount];
        tangents = new Vector4[VertexCount];
        colors = new Color32[VertexCount];

        for (int i = 0; i < VertexCount; i++) {
            vertices[i] = this.vertices[i];
            normals[i] = this.normals[i];
            uvs[i] = this.uvs[i];
            tangents[i] = this.tangents[i];
            colors[i] = this.colors[i];
        }

        int[][] triangles;

        triangles = new int[this.triangles.Length][];
        for (int i = 0; i < triangles.Length; i++) {

            triangles[i] = new int[TriangleCount[i]];
            for (int j = 0; j < triangles[i].Length; j++) {
                triangles[i][j] = this.triangles[i][j];
            }
        }


        Mesh mesh = new Mesh {
            indexFormat = VertexCount > 65000 ? UnityEngine.Rendering.IndexFormat.UInt32 : UnityEngine.Rendering.IndexFormat.UInt16,
            vertices = vertices,
            normals = normals,
            uv = uvs,
            tangents = tangents,
            colors32 = colors,
            subMeshCount = TriangleCount.Length
        };

        for (int i = 0; i < TriangleCount.Length; i++) {
            mesh.SetTriangles(triangles[i], i);
        }

        if (clear) {

            VertexCount = 0;
            for (int i = 0; i < TriangleCount.Length; i++) {
                TriangleCount[i] = 0;
            }

        }

        return mesh;
    }
}
